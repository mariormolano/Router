import './assets/css/base/base.css';
import './assets/css/componentes/card.css'

function App() {
  return (
    <>

    </>
  );
}

export default App;
